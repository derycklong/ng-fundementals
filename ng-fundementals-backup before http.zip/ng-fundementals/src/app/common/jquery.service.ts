import { InjectionToken} from '@angular/core'

export let JQUERY_TOKEN = new InjectionToken<Object>('jquery')

